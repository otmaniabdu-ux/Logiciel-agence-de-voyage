import { DCAConfig, Trade, StrategyResult, CryptoData } from '../types';

export class DCAStrategy {
  private config: DCAConfig;
  private capital: number;
  private currentLevel: number;
  private entryPrices: number[];
  private quantities: number[];
  private trades: Trade[];
  private portfolioHistory: Array<{ timestamp: Date; value: number; price: number }>;

  constructor(config: DCAConfig) {
    this.config = config;
    this.capital = config.initialCapital;
    this.currentLevel = 0;
    this.entryPrices = [];
    this.quantities = [];
    this.trades = [];
    this.portfolioHistory = [];
  }

  private getAveragePrice(): number {
    if (this.entryPrices.length === 0) return 0;
    
    const totalCost = this.entryPrices.reduce(
      (sum, price, i) => sum + price * this.quantities[i], 0
    );
    const totalQuantity = this.quantities.reduce((sum, qty) => sum + qty, 0);
    
    return totalQuantity > 0 ? totalCost / totalQuantity : 0;
  }

  private getTotalQuantity(): number {
    return this.quantities.reduce((sum, qty) => sum + qty, 0);
  }

  private shouldBuy(currentPrice: number): boolean {
    if (this.currentLevel >= this.config.buyLevels.length) return false;
    if (this.currentLevel === 0) return true;

    const lastPrice = this.entryPrices[this.entryPrices.length - 1];
    const priceChange = (currentPrice - lastPrice) / lastPrice;
    
    return priceChange <= this.config.buyTriggers[this.currentLevel];
  }

  private shouldSell(currentPrice: number): boolean {
    if (this.entryPrices.length === 0) return false;
    
    const avgPrice = this.getAveragePrice();
    return (currentPrice - avgPrice) / avgPrice >= this.config.profitTarget;
  }

  private buy(price: number, timestamp: Date): void {
    if (this.currentLevel >= this.config.buyLevels.length) return;

    const amount = this.config.initialCapital * this.config.buyLevels[this.currentLevel];
    if (amount > this.capital) return;

    const quantity = amount / price;
    
    this.entryPrices.push(price);
    this.quantities.push(quantity);
    this.capital -= amount;
    this.currentLevel++;

    this.trades.push({
      timestamp,
      type: 'BUY',
      price,
      quantity,
      amount,
      level: this.currentLevel
    });
  }

  private sell(price: number, timestamp: Date): void {
    if (this.quantities.length === 0) return;

    const totalQuantity = this.getTotalQuantity();
    const totalAmount = totalQuantity * price;
    const avgBuyPrice = this.getAveragePrice();

    this.capital += totalAmount;

    this.trades.push({
      timestamp,
      type: 'SELL',
      price,
      quantity: totalQuantity,
      amount: totalAmount,
      avgBuyPrice
    });

    // Reset positions
    this.entryPrices = [];
    this.quantities = [];
    this.currentLevel = 0;
  }

  private updatePortfolioValue(price: number, timestamp: Date): void {
    const positionValue = this.getTotalQuantity() * price;
    const totalValue = this.capital + positionValue;

    this.portfolioHistory.push({
      timestamp,
      value: totalValue,
      price
    });
  }

  public runStrategy(data: Array<{ timestamp: Date; price: number }>): StrategyResult {
    // Reset strategy
    this.capital = this.config.initialCapital;
    this.currentLevel = 0;
    this.entryPrices = [];
    this.quantities = [];
    this.trades = [];
    this.portfolioHistory = [];

    for (const { timestamp, price } of data) {
      if (this.shouldBuy(price)) {
        this.buy(price, timestamp);
      } else if (this.shouldSell(price)) {
        this.sell(price, timestamp);
      }

      this.updatePortfolioValue(price, timestamp);
    }

    const finalValue = this.portfolioHistory[this.portfolioHistory.length - 1]?.value || this.config.initialCapital;
    const totalReturn = ((finalValue - this.config.initialCapital) / this.config.initialCapital) * 100;
    
    // Calculate max drawdown
    let maxDrawdown = 0;
    let peak = this.config.initialCapital;
    
    for (const { value } of this.portfolioHistory) {
      if (value > peak) peak = value;
      const drawdown = ((peak - value) / peak) * 100;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    }

    return {
      finalValue,
      totalReturn,
      remainingCapital: this.capital,
      positionValue: this.getTotalQuantity() * (data[data.length - 1]?.price || 0),
      totalTrades: this.trades.length,
      buyTrades: this.trades.filter(t => t.type === 'BUY').length,
      sellTrades: this.trades.filter(t => t.type === 'SELL').length,
      maxDrawdown,
      trades: [...this.trades],
      portfolioHistory: [...this.portfolioHistory]
    };
  }
}

export function calculateBuyHoldReturn(
  data: Array<{ timestamp: Date; price: number }>,
  initialCapital: number
): { finalValue: number; totalReturn: number } {
  if (data.length === 0) return { finalValue: initialCapital, totalReturn: 0 };

  const firstPrice = data[0].price;
  const lastPrice = data[data.length - 1].price;
  const quantity = initialCapital / firstPrice;
  const finalValue = quantity * lastPrice;
  const totalReturn = ((finalValue - initialCapital) / initialCapital) * 100;

  return { finalValue, totalReturn };
}