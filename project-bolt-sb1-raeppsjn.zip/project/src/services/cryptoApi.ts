const COINGECKO_API = 'https://api.coingecko.com/api/v3';

// For demo purposes, we'll use the free tier endpoint
// In production, you should add your API key as an environment variable
const API_KEY = "CG-xntcxr4x5TbpLmVJmBJG4LgC";

const CRYPTO_MAP: Record<string, string> = {
  'ADA': 'cardano',
  'ATOM': 'cosmos',
  'WLD': 'worldcoin-wld',
  'BTC': 'bitcoin',
  'ETH': 'ethereum',
  'DOT': 'polkadot',
  'LINK': 'chainlink',
  'UNI': 'uniswap',
  'AAVE': 'aave',
  'MATIC': 'matic-network'
};

export async function fetchCryptoData(
  symbol: string,
  startDate: string,
  endDate: string
): Promise<Array<{ timestamp: Date; price: number }>> {
  try {
    const coinId = CRYPTO_MAP[symbol.toUpperCase()];
    if (!coinId) {
      throw new Error(`Crypto ${symbol} non supporté`);
    }

    const start = Math.floor(new Date(startDate).getTime() / 1000);
    const end = Math.floor(new Date(endDate).getTime() / 1000);
    
    // Build URL with optional API key
    let url = `${COINGECKO_API}/coins/${coinId}/market_chart/range?vs_currency=usd&from=${start}&to=${end}`;
    if (API_KEY) {
      url += `&x_cg_demo_api_key=${API_KEY}`;
    }
    
    const response = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'DCA-Crypto-Analyzer/1.0'
      }
    });
    
    if (!response.ok) {
      if (response.status === 401) {
        throw new Error(`Erreur d'authentification API (401). La clé API demo pourrait être expirée ou invalide.`);
      } else if (response.status === 429) {
        throw new Error(`Limite de taux API atteinte (429). Veuillez réessayer plus tard.`);
      } else if (response.status === 404) {
        throw new Error(`Crypto ${symbol} non trouvée (404). Vérifiez le symbole.`);
      } else {
        throw new Error(`Erreur API: ${response.status} - ${response.statusText}`);
      }
    }
    
    const data = await response.json();
    
    if (!data.prices || !Array.isArray(data.prices) || data.prices.length === 0) {
      throw new Error(`Aucune donnée de prix trouvée pour ${symbol} sur la période spécifiée`);
    }
    
    return data.prices.map(([timestamp, price]: [number, number]) => ({
      timestamp: new Date(timestamp),
      price
    }));
  } catch (error) {
    console.error(`Erreur lors de la récupération de ${symbol}:`, error);
    throw error;
  }
}

export function getAvailableCryptos(): Array<{ symbol: string; name: string }> {
  return [
    { symbol: 'ADA', name: 'Cardano' },
    { symbol: 'ATOM', name: 'Cosmos' },
    { symbol: 'WLD', name: 'Worldcoin' },
    { symbol: 'BTC', name: 'Bitcoin' },
    { symbol: 'ETH', name: 'Ethereum' },
    { symbol: 'DOT', name: 'Polkadot' },
    { symbol: 'LINK', name: 'Chainlink' },
    { symbol: 'UNI', name: 'Uniswap' },
    { symbol: 'AAVE', name: 'Aave' },
    { symbol: 'MATIC', name: 'Polygon' }
  ];
}