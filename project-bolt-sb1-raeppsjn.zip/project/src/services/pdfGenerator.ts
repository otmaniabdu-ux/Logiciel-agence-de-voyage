import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { AnalysisResult, DCAConfig } from '../types';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export async function generatePDF(
  results: AnalysisResult[],
  config: DCAConfig
): Promise<void> {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  // Page de couverture
  pdf.setFontSize(24);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Rapport d\'Analyse DCA', pageWidth / 2, 40, { align: 'center' });
  
  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Stratégie Dollar Cost Averaging', pageWidth / 2, 55, { align: 'center' });
  
  pdf.setFontSize(12);
  pdf.text(`Période d'analyse: ${config.startDate} - ${config.endDate}`, pageWidth / 2, 70, { align: 'center' });
  pdf.text(`Capital initial: ${config.initialCapital.toLocaleString()} USD`, pageWidth / 2, 80, { align: 'center' });
  pdf.text(`Généré le: ${format(new Date(), 'dd MMMM yyyy à HH:mm', { locale: fr })}`, pageWidth / 2, 90, { align: 'center' });

  // Configuration de la stratégie
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Configuration de la Stratégie', 20, 120);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  let yPosition = 135;
  
  pdf.text(`• Niveaux d'achat: ${config.buyLevels.map(l => (l * 100).toFixed(1) + '%').join(', ')}`, 25, yPosition);
  yPosition += 8;
  pdf.text(`• Déclencheurs: ${config.buyTriggers.map(t => (t * 100).toFixed(1) + '%').join(', ')}`, 25, yPosition);
  yPosition += 8;
  pdf.text(`• Objectif de profit: ${(config.profitTarget * 100).toFixed(1)}%`, 25, yPosition);
  yPosition += 8;
  pdf.text(`• Cryptomonnaies analysées: ${config.symbols.join(', ')}`, 25, yPosition);

  // Résultats par crypto
  yPosition += 20;
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Résultats Détaillés', 20, yPosition);
  
  yPosition += 15;
  
  for (const result of results) {
    if (yPosition > pageHeight - 60) {
      pdf.addPage();
      yPosition = 30;
    }
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`${result.symbol}`, 20, yPosition);
    yPosition += 10;
    
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    
    const lines = [
      `Valeur finale DCA: ${result.dca.finalValue.toFixed(2)} USD (${result.dca.totalReturn.toFixed(2)}%)`,
      `Valeur finale B&H: ${result.buyHold.finalValue.toFixed(2)} USD (${result.buyHold.totalReturn.toFixed(2)}%)`,
      `Surperformance: ${(result.dca.totalReturn - result.buyHold.totalReturn).toFixed(2)}%`,
      `Trades exécutés: ${result.dca.totalTrades} (${result.dca.buyTrades} achats, ${result.dca.sellTrades} ventes)`,
      `Drawdown maximum: ${result.dca.maxDrawdown.toFixed(2)}%`
    ];
    
    for (const line of lines) {
      pdf.text(line, 25, yPosition);
      yPosition += 7;
    }
    yPosition += 10;
  }

  // Résumé global
  if (yPosition > pageHeight - 80) {
    pdf.addPage();
    yPosition = 30;
  }
  
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Résumé Global', 20, yPosition);
  yPosition += 15;
  
  const avgDCAReturn = results.reduce((sum, r) => sum + r.dca.totalReturn, 0) / results.length;
  const avgBHReturn = results.reduce((sum, r) => sum + r.buyHold.totalReturn, 0) / results.length;
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.text(`Rendement moyen DCA: ${avgDCAReturn.toFixed(2)}%`, 25, yPosition);
  yPosition += 8;
  pdf.text(`Rendement moyen Buy & Hold: ${avgBHReturn.toFixed(2)}%`, 25, yPosition);
  yPosition += 8;
  pdf.text(`Surperformance moyenne: ${(avgDCAReturn - avgBHReturn).toFixed(2)}%`, 25, yPosition);

  // Capture des graphiques
  try {
    const chartElements = document.querySelectorAll('.chart-container');
    
    for (let i = 0; i < chartElements.length && i < 3; i++) {
      const element = chartElements[i] as HTMLElement;
      const canvas = await html2canvas(element, {
        backgroundColor: '#ffffff',
        scale: 2
      });
      
      pdf.addPage();
      const imgData = canvas.toDataURL('image/png');
      const imgWidth = pageWidth - 40;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 20, 20, imgWidth, Math.min(imgHeight, pageHeight - 40));
    }
  } catch (error) {
    console.warn('Impossible de capturer les graphiques:', error);
  }

  // Télécharger le PDF
  const fileName = `rapport_dca_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.pdf`;
  pdf.save(fileName);
}