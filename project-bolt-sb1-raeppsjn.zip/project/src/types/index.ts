export interface DCAConfig {
  initialCapital: number;
  buyLevels: number[];
  buyTriggers: number[];
  profitTarget: number;
  startDate: string;
  endDate: string;
  symbols: string[];
}

export interface Trade {
  timestamp: Date;
  type: 'BUY' | 'SELL';
  price: number;
  quantity: number;
  amount: number;
  level?: number;
  avgBuyPrice?: number;
}

export interface StrategyResult {
  finalValue: number;
  totalReturn: number;
  remainingCapital: number;
  positionValue: number;
  totalTrades: number;
  buyTrades: number;
  sellTrades: number;
  maxDrawdown: number;
  trades: Trade[];
  portfolioHistory: Array<{ timestamp: Date; value: number; price: number }>;
}

export interface CryptoData {
  symbol: string;
  prices: Array<{ timestamp: Date; price: number }>;
}

export interface AnalysisResult {
  symbol: string;
  dca: StrategyResult;
  buyHold: {
    finalValue: number;
    totalReturn: number;
  };
}