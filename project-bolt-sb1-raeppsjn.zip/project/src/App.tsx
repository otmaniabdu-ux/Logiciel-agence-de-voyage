import React, { useState } from 'react';
import { ConfigForm } from './components/ConfigForm';
import { ResultsDisplay } from './components/ResultsDisplay';
import { DCAConfig, AnalysisResult } from './types';
import { fetchCryptoData } from './services/cryptoApi';
import { DCAStrategy, calculateBuyHoldReturn } from './services/dcaStrategy';
import { generatePDF } from './services/pdfGenerator';
import { TrendingUp, AlertCircle, BarChart3 } from 'lucide-react';

function App() {
  const [results, setResults] = useState<AnalysisResult[]>([]);
  const [config, setConfig] = useState<DCAConfig | null>(null);
  const [loading, setLoading] = useState(false);
  const [generatingPDF, setGeneratingPDF] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalysis = async (newConfig: DCAConfig) => {
    setLoading(true);
    setError(null);
    setResults([]);
    setConfig(newConfig);

    try {
      const analysisResults: AnalysisResult[] = [];
      let successCount = 0;
      const errors: string[] = [];
      

      for (const symbol of newConfig.symbols) {
        try {
          console.log(`Récupération des données pour ${symbol}...`);
          const cryptoData = await fetchCryptoData(symbol, newConfig.startDate, newConfig.endDate);
          
          if (cryptoData.length === 0) {
            throw new Error(`Aucune donnée trouvée pour ${symbol}`);
          }

          // Stratégie DCA
          const dcaStrategy = new DCAStrategy(newConfig);
          const dcaResult = dcaStrategy.runStrategy(cryptoData);

          // Buy & Hold
          const buyHoldResult = calculateBuyHoldReturn(cryptoData, newConfig.initialCapital);

          analysisResults.push({
            symbol,
            dca: dcaResult,
            buyHold: buyHoldResult
          });

          console.log(`✓ ${symbol} analysé avec succès`);
          successCount++;
        } catch (symbolError) {
          const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
          console.error(`Erreur pour ${symbol}:`, errorMessage);
          errors.push(`${symbol}: ${errorMessage}`);
        }
      }

      if (successCount === 0) {
        const errorDetails = errors.length > 0 ? `\n\nDétails des erreurs:\n${errors.join('\n')}` : '';
        throw new Error(`Aucune donnée n'a pu être récupérée pour les cryptomonnaies sélectionnées.${errorDetails}\n\nSuggestions:\n- Vérifiez votre connexion internet\n- Essayez avec une période plus récente\n- Contactez le support si le problème persiste`);
      }
      
      if (errors.length > 0) {
        console.warn(`Certaines cryptomonnaies n'ont pas pu être récupérées: ${errors.join(', ')}`);
      }

      setResults(analysisResults);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur inattendue s\'est produite');
      console.error('Erreur lors de l\'analyse:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleGeneratePDF = async () => {
    if (!config || results.length === 0) return;

    setGeneratingPDF(true);
    try {
      await generatePDF(results, config);
    } catch (err) {
      setError('Erreur lors de la génération du PDF');
      console.error('Erreur PDF:', err);
    } finally {
      setGeneratingPDF(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-lg">
                <BarChart3 className="h-8 w-8 text-white" />
              </div>
              <div className="ml-4">
                <h1 className="text-3xl font-bold text-gray-900">DCA Crypto Analyzer</h1>
                <p className="text-gray-600">Analyseur de stratégie Dollar Cost Averaging</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" />
                <span>Stratégies avancées</span>
              </div>
              <div className="flex items-center">
                <BarChart3 className="h-4 w-4 mr-1" />
                <span>Rapports détaillés</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Erreur */}
        {error && (
          <div className="mb-8 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-red-600 mr-3" />
              <div>
                <h3 className="text-red-800 font-medium">Erreur lors de l'analyse</h3>
                <p className="text-red-700 text-sm mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Formulaire de configuration */}
        <div className="mb-8">
          <ConfigForm onSubmit={handleAnalysis} loading={loading} />
        </div>

        {/* Résultats */}
        {results.length > 0 && config && (
          <ResultsDisplay
            results={results}
            config={config}
            onGeneratePDF={handleGeneratePDF}
            generatingPDF={generatingPDF}
          />
        )}

        {/* État de chargement */}
        {loading && (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Analyse en cours...</h3>
            <p className="text-gray-600">
              Récupération des données et calcul des stratégies DCA vs Buy & Hold
            </p>
          </div>
        )}

        {/* Message d'accueil */}
        {results.length === 0 && !loading && !error && (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <BarChart3 className="h-10 w-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Bienvenue dans votre analyseur DCA
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Configurez votre stratégie Dollar Cost Averaging personnalisée et comparez-la 
              au Buy & Hold traditionnel sur les cryptomonnaies de votre choix. 
              Obtenez des rapports détaillés avec graphiques et métriques de performance.
            </p>
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto text-left">
              <div className="bg-blue-50 p-4 rounded-lg">
                <TrendingUp className="h-8 w-8 text-blue-600 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Stratégies Avancées</h4>
                <p className="text-sm text-gray-600">
                  Configurez des niveaux d'achat multiples avec déclencheurs personnalisables
                </p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <BarChart3 className="h-8 w-8 text-green-600 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Analyses Détaillées</h4>
                <p className="text-sm text-gray-600">
                  Visualisations interactives et métriques de performance complètes
                </p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <AlertCircle className="h-8 w-8 text-purple-600 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Rapports PDF</h4>
                <p className="text-sm text-gray-600">
                  Générez et partagez des rapports professionnels de vos analyses
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;