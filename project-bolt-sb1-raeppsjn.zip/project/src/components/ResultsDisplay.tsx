import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { AnalysisResult, DCAConfig } from '../types';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { TrendingUp, TrendingDown, DollarSign, Target, Activity, FileText } from 'lucide-react';

interface ResultsDisplayProps {
  results: AnalysisResult[];
  config: DCAConfig;
  onGeneratePDF: () => void;
  generatingPDF: boolean;
}

export function ResultsDisplay({ results, config, onGeneratePDF, generatingPDF }: ResultsDisplayProps) {
  if (results.length === 0) return null;

  const avgDCAReturn = results.reduce((sum, r) => sum + r.dca.totalReturn, 0) / results.length;
  const avgBHReturn = results.reduce((sum, r) => sum + r.buyHold.totalReturn, 0) / results.length;
  const outperformance = avgDCAReturn - avgBHReturn;

  // Préparation des données pour les graphiques
  const performanceData = results.map(result => ({
    symbol: result.symbol,
    dca: result.dca.totalReturn,
    buyHold: result.buyHold.totalReturn,
    outperformance: result.dca.totalReturn - result.buyHold.totalReturn
  }));

  const portfolioEvolutionData = results[0]?.dca.portfolioHistory.map((point, index) => ({
    date: point.timestamp.getTime(),
    dateFormatted: format(point.timestamp, 'dd/MM', { locale: fr }),
    ...results.reduce((acc, result) => {
      const portfolioPoint = result.dca.portfolioHistory[index];
      if (portfolioPoint) {
        acc[`${result.symbol}_value`] = portfolioPoint.value;
        acc[`${result.symbol}_return`] = ((portfolioPoint.value - config.initialCapital) / config.initialCapital) * 100;
      }
      return acc;
    }, {} as Record<string, number>)
  })) || [];

  return (
    <div className="space-y-8">
      {/* En-tête avec résumé global */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-3xl font-bold mb-2">Résultats de l'Analyse DCA</h2>
            <p className="text-blue-100">
              Période: {config.startDate} → {config.endDate} | 
              Capital: {config.initialCapital.toLocaleString()} USD
            </p>
          </div>
          <button
            onClick={onGeneratePDF}
            disabled={generatingPDF}
            className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transform hover:scale-105 transition-all duration-200 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {generatingPDF ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600 mr-2"></div>
            ) : (
              <FileText className="h-5 w-5 mr-2" />
            )}
            Générer PDF
          </button>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <TrendingUp className="h-6 w-6 mr-2" />
              <span className="font-semibold">DCA Moyen</span>
            </div>
            <p className="text-2xl font-bold">{avgDCAReturn.toFixed(2)}%</p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <Activity className="h-6 w-6 mr-2" />
              <span className="font-semibold">Buy & Hold Moyen</span>
            </div>
            <p className="text-2xl font-bold">{avgBHReturn.toFixed(2)}%</p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <Target className="h-6 w-6 mr-2" />
              <span className="font-semibold">Surperformance</span>
            </div>
            <p className={`text-2xl font-bold ${outperformance >= 0 ? 'text-green-300' : 'text-red-300'}`}>
              {outperformance >= 0 ? '+' : ''}{outperformance.toFixed(2)}%
            </p>
          </div>
        </div>
      </div>

      {/* Graphique de performance comparative */}
      <div className="bg-white rounded-lg shadow-lg p-6 chart-container">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Performance Comparative par Crypto</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="symbol" />
            <YAxis />
            <Tooltip 
              formatter={(value: number) => [`${value.toFixed(2)}%`, '']}
              labelFormatter={(label) => `${label}`}
            />
            <Legend />
            <Bar dataKey="dca" fill="#2563EB" name="DCA Strategy" />
            <Bar dataKey="buyHold" fill="#10B981" name="Buy & Hold" />
            <Bar dataKey="outperformance" fill="#F59E0B" name="Surperformance" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Évolution du portefeuille */}
      {portfolioEvolutionData.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6 chart-container">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Évolution des Rendements (%)</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={portfolioEvolutionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date"
                type="number"
                scale="time"
                domain={['dataMin', 'dataMax']}
                tickFormatter={(timestamp) => format(new Date(timestamp), 'dd/MM', { locale: fr })}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(timestamp) => format(new Date(timestamp as number), 'dd MMMM yyyy', { locale: fr })}
                formatter={(value: number) => [`${value.toFixed(2)}%`, '']}
              />
              <Legend />
              {results.map((result, index) => (
                <Line 
                  key={result.symbol}
                  type="monotone"
                  dataKey={`${result.symbol}_return`}
                  stroke={['#2563EB', '#10B981', '#F59E0B', '#EF4444'][index % 4]}
                  strokeWidth={2}
                  name={result.symbol}
                  dot={false}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Détails par cryptomonnaie */}
      <div className="grid gap-6">
        {results.map((result) => (
          <div key={result.symbol} className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold text-gray-900">{result.symbol}</h3>
              <div className="text-right">
                <p className="text-sm text-gray-500">Surperformance</p>
                <p className={`text-lg font-bold ${result.dca.totalReturn - result.buyHold.totalReturn >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {result.dca.totalReturn - result.buyHold.totalReturn >= 0 ? '+' : ''}
                  {(result.dca.totalReturn - result.buyHold.totalReturn).toFixed(2)}%
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Stratégie DCA */}
              <div className="bg-blue-50 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <TrendingUp className="h-5 w-5 text-blue-600 mr-2" />
                  <h4 className="font-semibold text-gray-900">Stratégie DCA</h4>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Valeur finale:</span>
                    <span className="font-medium">{result.dca.finalValue.toFixed(2)} USD</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rendement total:</span>
                    <span className={`font-bold ${result.dca.totalReturn >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {result.dca.totalReturn >= 0 ? '+' : ''}{result.dca.totalReturn.toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trades exécutés:</span>
                    <span className="font-medium">{result.dca.totalTrades}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Drawdown max:</span>
                    <span className="font-medium text-red-600">{result.dca.maxDrawdown.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              {/* Buy & Hold */}
              <div className="bg-green-50 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Activity className="h-5 w-5 text-green-600 mr-2" />
                  <h4 className="font-semibold text-gray-900">Buy & Hold</h4>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Valeur finale:</span>
                    <span className="font-medium">{result.buyHold.finalValue.toFixed(2)} USD</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rendement total:</span>
                    <span className={`font-bold ${result.buyHold.totalReturn >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {result.buyHold.totalReturn >= 0 ? '+' : ''}{result.buyHold.totalReturn.toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trades exécutés:</span>
                    <span className="font-medium">2 (1 achat, 1 vente)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Simplicité:</span>
                    <span className="font-medium text-green-600">Maximale</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Détail des trades DCA */}
            {result.dca.trades.length > 0 && (
              <div className="mt-4 bg-gray-50 rounded-lg p-4">
                <h5 className="font-semibold text-gray-900 mb-2">Détail des Trades DCA</h5>
                <div className="text-sm space-y-1 max-h-32 overflow-y-auto">
                  {result.dca.trades.slice(-5).map((trade, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        trade.type === 'BUY' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                      }`}>
                        {trade.type}
                      </span>
                      <span>{format(trade.timestamp, 'dd/MM/yyyy', { locale: fr })}</span>
                      <span className="font-medium">{trade.price.toFixed(4)} USD</span>
                      <span>{trade.amount.toFixed(2)} USD</span>
                    </div>
                  ))}
                  {result.dca.trades.length > 5 && (
                    <p className="text-xs text-gray-500 text-center">
                      ... et {result.dca.trades.length - 5} autres trades
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Configuration utilisée */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Configuration Utilisée</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="font-medium text-gray-700">Niveaux d'achat:</span>
            <p>{config.buyLevels.map(l => (l * 100).toFixed(1) + '%').join(', ')}</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Déclencheurs:</span>
            <p>{config.buyTriggers.map(t => (t * 100).toFixed(1) + '%').join(', ')}</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Objectif de profit:</span>
            <p>{(config.profitTarget * 100).toFixed(1)}%</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Cryptos analysées:</span>
            <p>{config.symbols.join(', ')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}