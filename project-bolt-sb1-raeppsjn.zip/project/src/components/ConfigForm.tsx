import React from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { DCAConfig } from '../types';
import { getAvailableCryptos } from '../services/cryptoApi';
import { Calendar, DollarSign, TrendingUp, Target, Plus, Minus } from 'lucide-react';

interface ConfigFormProps {
  onSubmit: (config: DCAConfig) => void;
  loading: boolean;
}

export function ConfigForm({ onSubmit, loading }: ConfigFormProps) {
  const { register, handleSubmit, control, watch, formState: { errors } } = useForm<DCAConfig>({
    defaultValues: {
      initialCapital: 500,
      buyLevels: [0.05, 0.10, 0.30, 0.55],
      buyTriggers: [0, -0.10, -0.20, -0.50],
      profitTarget: 0.10,
      startDate: '2024-01-01',
      endDate: '2024-12-31',
      symbols: ['ADA', 'ATOM', 'WLD']
    }
  });

  const { fields: levelFields, append: appendLevel, remove: removeLevel } = useFieldArray({
    control,
    name: 'buyLevels'
  });

  const { fields: triggerFields, append: appendTrigger, remove: removeTrigger } = useFieldArray({
    control,
    name: 'buyTriggers'
  });

  const { fields: symbolFields, append: appendSymbol, remove: removeSymbol } = useFieldArray({
    control,
    name: 'symbols'
  });

  const availableCryptos = getAvailableCryptos();

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Configuration de la Stratégie DCA</h2>
        <p className="text-gray-600">Configurez les paramètres de votre stratégie Dollar Cost Averaging</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Capital Initial */}
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="flex items-center mb-3">
            <DollarSign className="h-5 w-5 text-blue-600 mr-2" />
            <label className="text-lg font-semibold text-gray-900">Capital Initial</label>
          </div>
          <input
            type="number"
            min="100"
            step="10"
            {...register('initialCapital', { 
              required: 'Le capital initial est requis',
              min: { value: 100, message: 'Minimum 100 USD' }
            })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="500"
          />
          {errors.initialCapital && (
            <p className="text-red-500 text-sm mt-1">{errors.initialCapital.message}</p>
          )}
        </div>

        {/* Période d'analyse */}
        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center mb-3">
            <Calendar className="h-5 w-5 text-green-600 mr-2" />
            <label className="text-lg font-semibold text-gray-900">Période d'Analyse</label>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date de début</label>
              <input
                type="date"
                {...register('startDate', { required: 'La date de début est requise' })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
              {errors.startDate && (
                <p className="text-red-500 text-sm mt-1">{errors.startDate.message}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date de fin</label>
              <input
                type="date"
                {...register('endDate', { required: 'La date de fin est requise' })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
              {errors.endDate && (
                <p className="text-red-500 text-sm mt-1">{errors.endDate.message}</p>
              )}
            </div>
          </div>
        </div>

        {/* Niveaux d'achat */}
        <div className="bg-purple-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-purple-600 mr-2" />
              <label className="text-lg font-semibold text-gray-900">Niveaux d'Achat (%)</label>
            </div>
            <button
              type="button"
              onClick={() => appendLevel(0.05)}
              className="flex items-center px-3 py-1 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-1" />
              Ajouter
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {levelFields.map((field, index) => (
              <div key={field.id} className="relative">
                <input
                  type="number"
                  min="0.01"
                  max="1"
                  step="0.01"
                  {...register(`buyLevels.${index}` as const, { 
                    required: 'Requis',
                    min: { value: 0.01, message: 'Min 1%' },
                    max: { value: 1, message: 'Max 100%' }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="0.05"
                />
                {levelFields.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeLevel(index)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <Minus className="h-3 w-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Déclencheurs d'achat */}
        <div className="bg-orange-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-orange-600 mr-2 rotate-180" />
              <label className="text-lg font-semibold text-gray-900">Déclencheurs d'Achat (%)</label>
            </div>
            <button
              type="button"
              onClick={() => appendTrigger(-0.05)}
              className="flex items-center px-3 py-1 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-1" />
              Ajouter
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {triggerFields.map((field, index) => (
              <div key={field.id} className="relative">
                <input
                  type="number"
                  min="-1"
                  max="0"
                  step="0.01"
                  {...register(`buyTriggers.${index}` as const, { 
                    required: 'Requis',
                    min: { value: -1, message: 'Min -100%' },
                    max: { value: 0, message: 'Max 0%' }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  placeholder="-0.10"
                />
                {triggerFields.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeTrigger(index)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <Minus className="h-3 w-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Objectif de profit */}
        <div className="bg-yellow-50 rounded-lg p-4">
          <div className="flex items-center mb-3">
            <Target className="h-5 w-5 text-yellow-600 mr-2" />
            <label className="text-lg font-semibold text-gray-900">Objectif de Profit (%)</label>
          </div>
          <input
            type="number"
            min="0.01"
            max="2"
            step="0.01"
            {...register('profitTarget', { 
              required: 'L\'objectif de profit est requis',
              min: { value: 0.01, message: 'Minimum 1%' },
              max: { value: 2, message: 'Maximum 200%' }
            })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            placeholder="0.10"
          />
          {errors.profitTarget && (
            <p className="text-red-500 text-sm mt-1">{errors.profitTarget.message}</p>
          )}
        </div>

        {/* Cryptomonnaies */}
        <div className="bg-indigo-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <label className="text-lg font-semibold text-gray-900">Cryptomonnaies à Analyser</label>
            <button
              type="button"
              onClick={() => appendSymbol('BTC')}
              className="flex items-center px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-4 w-4 mr-1" />
              Ajouter
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {symbolFields.map((field, index) => (
              <div key={field.id} className="relative">
                <select
                  {...register(`symbols.${index}` as const, { required: 'Requis' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  {availableCryptos.map(crypto => (
                    <option key={crypto.symbol} value={crypto.symbol}>
                      {crypto.symbol} - {crypto.name}
                    </option>
                  ))}
                </select>
                {symbolFields.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeSymbol(index)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <Minus className="h-3 w-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 px-6 rounded-lg font-semibold text-lg hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {loading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Analyse en cours...
            </div>
          ) : (
            'Lancer l\'Analyse DCA'
          )}
        </button>
      </form>
    </div>
  );
}