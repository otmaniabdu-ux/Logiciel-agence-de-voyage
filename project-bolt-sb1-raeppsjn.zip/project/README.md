# DCA Crypto Analyzer

Une application web moderne pour analyser et comparer les performances de la stratégie Dollar Cost Averaging (DCA) avec la stratégie Buy & Hold sur les cryptomonnaies.

## 🚀 Fonctionnalités

### ✨ Configuration Personnalisable
- **Capital initial** : Définissez votre montant d'investissement
- **Niveaux d'achat** : Configurez les pourcentages du capital à investir à chaque niveau
- **Déclencheurs d'achat** : Définissez les seuils de baisse pour déclencher les achats
- **Objectif de profit** : Fixez le pourcentage de profit pour déclencher les ventes
- **Période d'analyse** : Choisissez la période de test de votre stratégie
- **Cryptomonnaies** : Sélectionnez parmi 10 cryptos populaires

### 📊 Analyses Avancées
- Comparaison automatique DCA vs Buy & Hold
- Calcul du drawdown maximum
- Historique détaillé des trades
- Métriques de performance complètes
- Visualisations interactives

### 📈 Visualisations
- Graphiques de performance comparative
- Évolution du portefeuille en temps réel
- Analyses de drawdown
- Comparaisons multi-cryptos

### 📄 Rapports PDF
- Génération automatique de rapports professionnels
- Inclusion des graphiques et métriques
- Résumé exécutif avec recommandations
- Téléchargement direct

## 🛠️ Technologies Utilisées

- **React 18** avec TypeScript
- **Tailwind CSS** pour le design
- **Recharts** pour les visualisations
- **React Hook Form** pour la gestion des formulaires
- **jsPDF & html2canvas** pour les rapports PDF
- **CoinGecko API** pour les données crypto
- **Lucide React** pour les icônes

## 💡 Stratégie DCA Expliquée

La stratégie Dollar Cost Averaging multi-niveaux fonctionne ainsi :

1. **Achat Initial** : Investissement du premier niveau au prix actuel
2. **Achats Échelonnés** : Achats supplémentaires quand le prix baisse selon les déclencheurs configurés
3. **Prise de Profit** : Vente complète quand le prix dépasse l'objectif de profit par rapport au prix moyen d'achat
4. **Répétition** : Le cycle recommence après chaque vente

### Exemple de Configuration
- Capital : 1000 USD
- Niveaux : [5%, 10%, 30%, 55%] = [50, 100, 300, 550 USD]
- Déclencheurs : [0%, -10%, -20%, -50%]
- Objectif : 10% de profit

## 🎯 Avantages de l'Application

### Pour les Investisseurs
- **Test de Stratégies** : Validez vos approches avant d'investir
- **Optimisation** : Trouvez les meilleurs paramètres pour votre profil
- **Comparaison** : Évaluez la performance vs stratégies passives

### Pour les Analystes
- **Rapports Professionnels** : Documentez vos analyses
- **Métriques Avancées** : Drawdown, Sharpe ratio, volatilité
- **Backtesting** : Testez sur différentes périodes historiques

## 📱 Interface Utilisateur

- **Design Moderne** : Interface inspirée des plateformes financières professionnelles
- **Responsive** : Optimisé pour desktop, tablette et mobile
- **Intuitive** : Formulaire guidé par étapes avec validation
- **Performante** : Calculs rapides et visualisations fluides

## 🔧 Utilisation

1. **Configuration** : Remplissez le formulaire avec vos paramètres
2. **Analyse** : Lancez l'analyse sur les cryptos sélectionnées
3. **Résultats** : Consultez les performances et graphiques
4. **Rapport** : Générez un PDF professionnel

## 🎨 Personnalisation

L'application utilise un système de design cohérent avec :
- Palette de couleurs financières (bleu, vert, orange)
- Animations et transitions fluides
- Micro-interactions pour l'engagement
- Graphiques interactifs et informatifs

## 🚀 Installation et Démarrage

```bash
npm install
npm run dev
```

L'application sera disponible sur `http://localhost:5173`

## 📊 Cryptomonnaies Supportées

- Bitcoin (BTC)
- Ethereum (ETH)
- Cardano (ADA)
- Cosmos (ATOM)
- Worldcoin (WLD)
- Polkadot (DOT)
- Chainlink (LINK)
- Uniswap (UNI)
- Aave (AAVE)
- Polygon (MATIC)

---

*Développé avec ❤️ pour optimiser vos stratégies d'investissement crypto*